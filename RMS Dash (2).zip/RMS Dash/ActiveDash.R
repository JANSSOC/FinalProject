library(timeDate)

### User defined functions
format.money <- function(x){
  y = paste0('$',formatC(as.numeric(x)/1000, format="f", digits=0, big.mark=","),'K')
  return(y)
}

format.units <- function(x){
  y = paste0(formatC(as.numeric(x), format="f", digits=0, big.mark=","))
}
### Function to manage dashboard data and filter when reactive.
calc <- function(rawData, dtype, rown=NA){
  
  print(paste0("Dashboard type: ", dtype))
  print(paste0("Selection: ", rown))
  
  # unpack from rawData object
  for(i in 1:length(rawData)){
    tempobj = rawData[[i]]
    eval(parse(text=paste(names(rawData)[i],"= tempobj")))
  }
  tempobj <- NULL

  ###  Day counts
  today = Sys.Date()  # as.Date('2017-01-24')
  now = as.timeDate(Sys.time())  # as.timeDate('2017-01-24 05:00:00',zone='EST')
  startTime = as.timeDate(paste(today,'07:00:00'),zone='EST')
  endTime = as.timeDate(paste(today,'19:00:00'),zone='EST')
  nHours = as.numeric(now-startTime)
  nHoursDay = as.numeric(endTime-startTime)
  percDay = nHours/nHoursDay
  
  if(percDay > 1){
    percDay = 1
  } else if(percDay < 0){
    percDay = 1e-99 # small number instead of 0 because of gauge color conflict
  }
  
  firstDay = timeFirstDayInMonth(today) # first of month
  lastDay = timeLastDayInMonth(today) # last of month
  ts = timeSequence(from=firstDay,to=lastDay) # create time series
  tsBiz = ts[isBizday(ts, timeDate(as.Date(holidayUTAS2$`Calendar Date`)))] # filter based on holidays
  nDaysMonth = length(tsBiz) # num of business days in month
  nDays = 0 # num of business days that have passed
  for(i in seq(1,length(tsBiz))){
    if(as.Date(tsBiz[i]) < today){
      nDays = nDays+1
    }
  }
  percMonth = (nDays+percDay)/nDaysMonth # percent of business days that passed
  
  ### fix data types
  ShipAll$`sales net value` = as.numeric(ShipAll$`sales net value`)
  ShipAll$`shipment date` = as.Date(ShipAll$`shipment date`)
  ShipAll$tat = as.numeric(ShipAll$tat)
  ShipAll$'total tat' = as.numeric(ShipAll$'total tat')
  ShipMonth$'Total' = as.numeric(ShipMonth$'Total')
  OutputMonthGate$Total = as.numeric(OutputMonthGate$Total)
  Quoted$`Start Time` = as.Date(Quoted$`Start Time`)
  SITE$SalesMonthGoal = as.numeric(SITE$SalesMonthGoal)
  CAMGOALS$qtyMonthGoal = as.numeric(CAMGOALS$qtyMonthGoal)
  SAMGOALS$qtyMonthGoal = as.numeric(SAMGOALS$qtyMonthGoal)
  
  ### Clean data for filters
  if(dtype=='CAM'){
    ShipMonth = ShipMonth[!is.na(ShipMonth$CAM),]
    ShipPOMonth = ShipPOMonth[!is.na(ShipPOMonth$CAM),]
    WIPGATE = WIPGATE[!is.na(WIPGATE$CAM),]
    Backlog = Backlog[!is.na(Backlog$CAM),]
  }else if(dtype=='SAM'){
    ShipMonth = ShipMonth[!is.na(ShipMonth$SAM),]
    ShipPOMonth = ShipPOMonth[!is.na(ShipPOMonth$SAM),]
    WIPGATE = WIPGATE[!is.na(WIPGATE$SAM),]
    Backlog = Backlog[!is.na(Backlog$SAM),]
  }
  
  ShipDirect = ShipAll[ShipAll$destination=='Direct',]
  ### Sort data for filters
  if(dtype=='Site'){
    qtyMonthGoal = SITE$QtyMonthGoal
    salesMonthGoal = SITE$SalesMonthGoal
    salesDayGoal = salesMonthGoal/nDaysMonth
  }else if(dtype=='CAM'){
    WIPGATE = WIPGATE[WIPGATE$CAM==rown,]
    ShipMonth = ShipMonth[ShipMonth$CAM==rown,]
    Backlog = Backlog[Backlog$CAM==rown,]
    ShipPOMonth = ShipPOMonth[ShipPOMonth$CAM==rown,]
    CAMGOALS = CAMGOALS[CAMGOALS$CAM==rown,]
    print(CAMGOALS)
    qtyMonthGoal = CAMGOALS$qtyMonthGoal[1]
    print(qtyMonthGoal)
  }else if(dtype=='SAM'){
    WIPGATE = WIPGATE[WIPGATE$SAM==rown,]
    ShipMonth = ShipMonth[ShipMonth$SAM==rown,]
    Backlog = Backlog[Backlog$SAM==rown,]
    ShipPOMonth = ShipPOMonth[ShipPOMonth$SAM==rown,]
    SAMGOALS = SAMGOALS[SAMGOALS$SAM==rown,] 
    print(SAMGOALS)
    qtyMonthGoal = SAMGOALS$qtyMonthGoal[1]
    print(qtyMonthGoal)
  }

  ### Goals
  fr = 1
  qtyMonthGoal = qtyMonthGoal*fr

  ### Expectations
  qtyExpMonth = percMonth*qtyMonthGoal
  
  ### Shipped data

  ShipPOMonth = aggregate(Total ~ Total, data = ShipPOMonth, FUN = sum)
  ShipMonth = aggregate(Total ~ Total, data = ShipMonth, FUN = sum)

  qtyMonth = ShipMonth$Total[1]
  qtyPOMonth = ShipPOMonth$Total[1]

  dfShipCust = data.frame(c(qtyMonth,qtyExpMonth,qtyMonthGoal))
  colnames(dfShipCust) = c('Quantity')
  rownames(dfShipCust) = c('Total Output','MTD Goal','EOM Goal')
  dfShipCust$Quantity = format.units(dfShipCust$Quantity)
  
  dfShipPOCust = data.frame(c(qtyMonth,qtyExpMonth,qtyMonthGoal))
  colnames(dfShipPOCust) = c('Quantity')
  rownames(dfShipPOCust) = c('Total Output','MTD Goal','EOM Goal')
  dfShipPOCust$Quantity = format.units(dfShipPOCust$Quantity)

  ### Backlog Status
  BacklogTotal = aggregate(Total ~ DATE, data = Backlog, FUN = sum)
  urows = unique(BacklogTotal$DATE)
  rows = urows
  cols = 'Total'
  dfBacklog = data.frame(BacklogTotal)
  
  
  ### Total Wip 
  wipTotal = aggregate(Total ~ Total, data = WIPGATE, FUN = sum)
  wipTotal = wipTotal$Total[1]
  rows = 'Total'
  cols = 'Total'
  dfUnits = data.frame(wipTotal)
  colnames(dfUnits) = cols
  rownames(dfUnits) = rows
  
  ### Current Gate Status
    getGateStatus = function(WIP){
    # get unique status
    uStatus = unique(WIP$INDICATOR)

    # get unique gates
    uGate = unique(WIP$GATE)
    uGate = sort(uGate)

    df = data.frame(matrix(NA, nrow = 6, ncol = length(uStatus)))
    names(df) = uStatus
    rownames(df) = paste0('Gate ', seq(0,5))
    
    dfGrp = aggregate(Total ~ GATE + INDICATOR, data = WIP, FUN = sum)
    dfGrp1 = aggregate(Total ~ Total, data = WIP, FUN = sum)

    for(j in seq(1,ncol(df))){
      Gate = as.numeric(dfGrp[dfGrp$INDICATOR==names(df)[j], 'GATE'])
      Val = dfGrp[dfGrp$INDICATOR==names(df)[j], 'Total']
      df[Gate, j] = Val
    }
    # df[is.na(df)] <- 0
    return(df)
  }
  
  dfGateStatus = getGateStatus(WIPGATE)

x = list(
  qtyMonth = qtyMonth,
  dfShipCust = dfShipCust,
  qtyPOMonth =  qtyPOMonth,
  dfShipPOCust = dfShipPOCust,
  dfBacklog = dfBacklog,
  dfUnits = dfUnits,
  wipTotal = wipTotal,
  dfGateStatus = dfGateStatus,
  qtyMonthGoal = qtyMonthGoal,
  qtyExpMonth = qtyExpMonth,
  dfQtyMonth = ShipMonth$Total[1]
)

# print(x)
  
  return(x)
  
}


