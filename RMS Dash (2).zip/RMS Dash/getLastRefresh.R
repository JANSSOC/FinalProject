library(RODBC)
getLastRefresh <- function(){
  con <- odbcDriverConnect('DRIVER={ODBC Driver 13 for SQL Server};PORT=1433;SERVER=uusmnd0m.utcaus.com;DATABASE=DMB;UID=DMB_Read;PWD=UTAS_2018!;')
  #con <- odbcDriverConnect('DRIVER={SQL Server};PORT=1433;SERVER=uusmnd0m.utcaus.com;DATABASE=OJT;UID=OJTBusiness;PWD=OJTBusin#ss1;')
  LastRefresh = as.character(sqlQuery(con, "select top 1 lastmodified from WIP$", as.is = T))
  LastRefresh = gsub('.{4}$', '', LastRefresh)
  odbcClose(con)
  # LastRefresh = as.character(read.csv('datesim.csv', as.is = T))
  return(LastRefresh)
}
