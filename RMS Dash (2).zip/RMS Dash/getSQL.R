queries = list(

ShipAll = "
-- Ship Direct
select SO as [sales order],[P/N] as material,[P/N DESCRIPTION] as description, [SO SHIP DT] as [shipment date], 'Direct' as destination,
'01' as dchl,Case when [CSL ONTIME] = 0 then 'NO' else 'YES' End as [otd-revised], [SO NET] as [sales net value], tat,'Lg ACM' as Cell,'Rotatives' as [Value Stream],'AMS Rotatives' as BU,dih as [total tat], Case when [DIH ONTIME] = 0 then 'NO' else 'YES' End as [otd-DIH]
from INTAKE_Current
where 
[job category] not in ('02', '04', '09') and
[job category] is not null and [RECIEPT DT] is not null and
[SO SHIP DT]  is not null and
month([SO SHIP DT]) = month(getdate()) and
year([SO SHIP DT]) = year(getdate())
"
,
GATEOUTPUT = "SELECT [SALES OFFICE] AS CAM,[Supplier Manager] AS SAM,[GATE], count(*)
  FROM [DMB].[dbo].[WIPStatus] as w
Left outer join INTAKE_Current as i on w.NOTIFICATION = i.NOTIFICATION
Where  month([STARTDATE]) = month(getdate()) and
year([STARTDATE]) = year(getdate()) and  NOT GATE = 'EXCH/LEASE/MOD'
group by GATE, [SALES OFFICE],[Supplier Manager]
"
,
WIPGATE = "Select INDICATOR, CONTRACT, GATE,[SALES OFFICE] AS CAM,[Supplier Manager] AS SAM, count(*) Total from 
(Select  CASE WHEN CONTRACT is Null then 'Misc' else CONTRACT end As CONTRACT, INDICATOR,[SALES OFFICE],[Supplier Manager], CASE WHEN INDICATOR = 'NEEDS REVIEW' Then 6 
WHEN INDICATOR = 'G2' THEN 3
WHEN INDICATOR = 'G1 QUOTE GEN' THEN 2
WHEN INDICATOR = 'G3' THEN 4
WHEN INDICATOR = 'EXCH/LEASE/MOD' THEN 0
WHEN INDICATOR = 'G1 SCM' THEN 2
WHEN INDICATOR = 'G4' THEN 5
WHEN INDICATOR = 'NOT RCV' THEN 1
END as GATE from [WIP_Current]) as w
WHERE NOT INDICATOR = 'EXCH/LEASE/MOD' 
Group by  INDICATOR, CONTRACT, GATE,[SALES OFFICE],[Supplier Manager]
Order by GATE
"
,
ShipMonth = "
select [SALES OFFICE] AS CAM,[Supplier Manager] AS SAM, Count(*) as Total
from INTAKE_Current
where 
[job category] not in ('02', '04', '09') and
[job category] is not null and [RECIEPT DT] is not null and
[SO SHIP DT]  is not null and
month([SO SHIP DT]) = month(getdate()) and
year([SO SHIP DT]) = year(getdate())
Group by [SALES OFFICE],[Supplier Manager]
"
,
Backlog = "SELECT [SALES OFFICE] as CAM
      ,[Supplier Manager] as SAM,Cast([LAST MODIFIED] as date) as DATE, count(*) as Total
  FROM [DMB].[dbo].[WIP_Snapshot]
  Where NOT [INDICATOR] = 'EXCH/LEASE/MOD'
  Group by [SALES OFFICE] ,[Supplier Manager],Cast([LAST MODIFIED] as date)
"
,
ShipPOMonth = "
select [SALES OFFICE] AS CAM,[Supplier Manager] AS SAM, Count(*) as Total
from INTAKE_Current
where 
[job category] not in ('02', '04', '09') and
[job category] is not null and [RECIEPT DT] is not null and
[PO SHIP DT]  is not null and
month([PO SHIP DT]) = month(getdate()) and
year([PO SHIP DT]) = year(getdate())
Group by [SALES OFFICE],[Supplier Manager]
"
,
OutputMonthGate = "select GATE, count(*) AS Total from WIPStatus
	Where month([STARTDATE]) = month(getdate()) and
year([STARTDATE ]) = year(getdate())
Group by GATE"
,
Quoted = "
SELECT [Message] as [Sales Order], [Created On] as [Start Time],'Lg ACM' as Cell,'Rotatives' as [Value Stream],'AMS Rotatives' as BU
  FROM [DMB].[dbo].[HOLDDAYS1$]
WHERE month([Created On]) = month(getdate()) and year([Created On]) = year(getdate()) and [Code] =  'RTQT'
"
,
SITE = "
SELECT SalesMonthGoal, QtyMonthGoal FROM SiteGoals
                WHERE MONTH([FirstOfMonth]) = MONTH(getdate()) AND YEAR([FirstOfMonth]) = YEAR(getdate())
"
,
CAMGOALS = "Select [sales office] as CAM, CASE WHEN Total is NULL Then 0 Else Total end as qtyMonthGoal from WIP_Current as w
left outer join (
SELECT [sales office] as CAM, COUNT(*) as Total FROM INTAKE_Current
WHERE [SNO CRTD] Between GETDATE()-35 AND Getdate()
Group by [SALES OFFICE]) s on s.CAM	= w.[Sales Office]
Where [Sales Office] is not null 
Group by [Sales Office],Total"
,
SAMGOALS = "Select [supplier manager] as SAM, CASE WHEN Total is NULL Then 0 Else Total end as qtyMonthGoal from WIP_Current as w
left outer join (
SELECT [supplier manager] as SAM, COUNT(*) as Total FROM INTAKE_Current
WHERE [SNO CRTD] Between GETDATE()-35 AND Getdate()
Group by [Supplier manager]) s on s.SAM	= w.[supplier manager]
Where [supplier manager] is not null 
Group by [supplier manager],Total"

,
holidayUTAS2 = "
select [Calendar Date] from refCalendar$
where [Work Day] = 0 and
year([Calendar Date]) = year(getdate()) and
datepart(dw, [Calendar Date]) != 1 and
datepart(dw, [Calendar Date]) != 7
"
)

library(RODBC)

getData2 <- function(){
  print('Refreshing SQL Server...')
  con <- odbcDriverConnect('DRIVER={ODBC Driver 13 for SQL Server};PORT=1433;SERVER=uusmnd0m.utcaus.com;DATABASE=DMB;UID=DMB_Read;PWD=UTAS_2018!;')
  #con <- odbcDriverConnect('DRIVER={ODBC Driver 13 for SQL Server};PORT=1433;SERVER=uusmnd0m.utcaus.com;DATABASE=OJT;UID=OJTBusiness;PWD=OJTBusin#ss1;')
  #con <- odbcDriverConnect('DRIVER={SQL Server};PORT=1433;SERVER=uusmnd0m.utcaus.com;DATABASE=OJT;UID=OJTBusiness;PWD=OJTBusin#ss1;')
  dfs = list()
  for(i in seq(length(queries))){
    dfs[[names(queries)[i]]] = sqlQuery(con, queries[[i]], as.is = T)
  }
  odbcClose(con)
  print('SQL Queries Complete')
  # print(dfs)
  return(dfs)
}
